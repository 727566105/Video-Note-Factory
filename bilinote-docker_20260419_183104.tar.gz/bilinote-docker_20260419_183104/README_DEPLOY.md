# BiliNote Docker 部署说明

## 部署步骤

### 1. 上传文件
将整个文件夹上传到飞牛 NAS

### 2. 配置环境变量
编辑 `.env` 文件，根据需要修改配置：

```bash
# 主要配置项
BACKEND_PORT=8483
APP_PORT=3015
TRANSCRIBER_TYPE=fast-whisper
WHISPER_MODEL_SIZE=base
```

### 3. 启动服务
```bash
docker-compose up -d --build
```

### 4. 访问应用
浏览器访问: http://你的NAS_IP:3015

## 数据持久化
建议在 docker-compose.yml 中添加数据卷挂载：

```yaml
volumes:
  - ./data:/app/data
  - ./note_results:/app/note_results
  - ./uploads:/app/uploads
```

## 常用命令
```bash
# 查看日志
docker-compose logs -f

# 停止服务
docker-compose down

# 重启服务
docker-compose restart
```
